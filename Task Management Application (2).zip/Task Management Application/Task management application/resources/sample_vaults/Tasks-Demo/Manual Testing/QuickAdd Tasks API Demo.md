# QuickAdd Tasks API Demo

This vault has a command `QuickAdd: Add task`, which is based upon the settings in the Tasks user guide: [Usage with QuickAdd](https://publish.obsidian.md/tasks/Advanced/Tasks+Api#Usage+with+QuickAdd).

It's modified to:

- Add a newline at the end of the new task.
- Enable running the action via this command.
- The command is pinned in the Command Palette.

## New Tasks

- [ ] #task Test task added via the API!
