# Fields for Functions - Demo

## Status

```tasks
group by function task.status.name
group by function task.status.symbol
group by function task.status.nextSymbol
group by function task.status.type

limit 10
```
