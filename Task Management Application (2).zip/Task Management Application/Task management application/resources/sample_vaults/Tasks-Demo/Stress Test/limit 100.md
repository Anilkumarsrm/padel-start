---
creation date: 2024-03-23 15:14
tags:
aliases:
  -
---

# limit 100

```tasks
folder includes {{query.file.folder}}
sort by path

# Use the filename as an instruction:
{{query.file.filenameWithoutExtension}}

#explain
```
