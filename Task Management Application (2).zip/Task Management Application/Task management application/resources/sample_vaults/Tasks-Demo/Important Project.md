# Important Project

- [ ] #task Something about interwebs 📅 2021-11-22
- [x] #task Something about s.th. ⏳ 2021-11-21 ✅ 2021-11-21

## Trash is important

- [ ] #task Also: take out the trash!
  - [ ] #task Throw the trash away
