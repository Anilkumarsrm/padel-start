- [ ] #task task 1 starting with a hyphen
- [ ] #task task 2 starting with a hyphen

* [ ] #task task 1 starting with an asterisk
* [ ] #task task 2 starting with an asterisk

+ [ ] #task task 1 starting with a plus sign
+ [ ] #task task 2 starting with a plus sign

1. [ ] #task task 1 in a numbered list
2. [ ] #task task 2 in a numbered list
