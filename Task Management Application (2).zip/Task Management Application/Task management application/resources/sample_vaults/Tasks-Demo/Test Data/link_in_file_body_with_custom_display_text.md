# link_in_file_body_with_custom_display_text

I link to [[yaml_tags_is_empty|a file and use custom display text]]

- [ ] #task Task in 'link_in_file_body_with_custom_display_text'
