---
test-link: "[[yaml_tags_is_empty]]"
---

# link_in_yaml

- [ ] #task Task in 'link_in_yaml'
