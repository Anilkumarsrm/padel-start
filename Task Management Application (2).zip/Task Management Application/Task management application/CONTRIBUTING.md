# Contribution Guidelines Obsidian Tasks

## Thank you

Thank you for wanting to contribute to Obsidian Tasks!
Every contribution is much appreciated!

## Extensive documentation for contributors

Please visit [**tasks-contributing**](https://publish.obsidian.md/tasks-contributing/) for lots of useful information about contributing to Tasks.

Many thanks!
