# Documentation and branches

## Current documentation

Since April 2023, the documentation is published from the `main` branch.

## Old Jekyll documentation

For documentation changes to show up at the old site, <https://obsidian-tasks-group.github.io/obsidian-tasks/> , they must be in the `gh-pages` branch.

Now that the content on `gh-pages` has been [replaced with redirects](https://github.com/obsidian-tasks-group/obsidian-tasks/commit/9bf0963ef41009146d46321be039f5a12465eccd), we do not expect to make any more changes to the `gh-pages` branch.
