module.exports = {
  trailingComma: 'all',
  printWidth: 120,
  tabWidth: 4,
  useTabs: false,
  singleQuote: true,
  bracketSpacing: true
};
