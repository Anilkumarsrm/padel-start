# multi_line_task_and_list_item

- [ ] #task Task in 'multi_line_task_and_list_item'
    task line 1
    task line 2
- muli-line list item in 'multi_line_task_and_list_item'
    list item line 1
    list item line 2

See: https://github.com/obsidian-tasks-group/obsidian-tasks/issues/2061:
Multi-line tasks (indented lines below a task items) are not shown in Reading mode and Tasks query results
