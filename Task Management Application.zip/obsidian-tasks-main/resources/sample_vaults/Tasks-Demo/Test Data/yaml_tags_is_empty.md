---
tags:
---

# yaml_tags_is_empty

- [ ] #task Task in 'yaml_tags_is_empty'
