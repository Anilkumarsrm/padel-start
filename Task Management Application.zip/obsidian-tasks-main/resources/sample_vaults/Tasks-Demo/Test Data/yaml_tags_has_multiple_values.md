---
tags:
  - multiple1
  - multiple2
---

# yaml_tags_has_multiple_values

- [ ] #task Task in 'yaml_tags_has_multiple_values'
