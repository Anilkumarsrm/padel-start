---
aliases:
  - YAML Alias 1
  - YAML Alias 2
---

# yaml_2_aliases

- [ ] #task Task in 'yaml_2_aliases'
