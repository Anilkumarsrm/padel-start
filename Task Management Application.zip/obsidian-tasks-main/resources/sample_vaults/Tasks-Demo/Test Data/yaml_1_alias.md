---
aliases:
  - YAML Alias 1
---

# yaml_1_alias

- [ ] #task Task in 'yaml_1_alias'
