---

kanban-plugin: basic

---

## Backlog

- [ ] #task Task in 'example_kanban'


%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%
