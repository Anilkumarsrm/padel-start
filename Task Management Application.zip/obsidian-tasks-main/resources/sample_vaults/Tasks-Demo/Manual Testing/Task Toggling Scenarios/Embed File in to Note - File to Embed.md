# Embed File in to Note - File to Embed

## Category 3

- [ ] #task task3a
- [ ] #task task3b
- [ ] #task task3c

## Category 4

- [ ] #task task4a
- [ ] #task task4b - has section and task number 0 when shown embedded in another file ^fromseparatefile
- [ ] #task task4c
