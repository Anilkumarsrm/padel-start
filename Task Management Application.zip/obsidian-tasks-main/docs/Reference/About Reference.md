---
publish: true
aliases:
  - Reference/Reference
---

# About Reference

<span class="related-pages">#index-pages</span>

This section provides reference material - content which is typically too detailed for other parts of the documentation.

## Reference section contents

- [[About Task Formats|Task Formats]]
- [[About Status Collections]]
