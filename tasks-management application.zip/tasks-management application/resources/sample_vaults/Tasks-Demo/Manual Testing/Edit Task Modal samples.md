# Edit Task Modal samples

## Task to edit

- [/] #task Task with every field set 🆔 y3yryw ⛔ c5mw2c,2ypqea 🔺 🔁 every April and December on the 1st and 24th ➕ 2024-04-27 🛫 2024-04-28 ⏳ 2024-04-29 📅 2024-04-30

## Tasks for testing dependencies

- [ ] #task Sample 1 🆔 c5mw2c
- [ ] #task Sample 2 🆔 2ypqea
- [ ] #task Sample 3 ⛔ y3yryw
- [ ] #task Sample 4 ⛔ y3yryw
