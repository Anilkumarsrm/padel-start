# Scheduled Implied - 2022-11-05

## Task(s)

- [ ] #task No date scheduled - should use date in filename as scheduled date - as shown by group title

## Query

```tasks
path includes Scheduled Implied
group by scheduled
```
