# comments_html_style

Whole task line is ignored by Obsidian's `cachedMetadata`:
<!--
- [ ] #task Whole task in 'comments_html_style'
-->

- [ ] #task Whole task in 'comments_html_style' - with commented-out tag: <!-- #i-am-ignored-by-obsidian  --> - is ignored by Obsidian's `cachedMetadata`, but Tasks recognises it
- [ ] #task Whole task in 'comments_html_style' - with commented-out link: <!-- [[comments_markdown_style]]  --> - is ignored by Obsidian's `cachedMetadata`
