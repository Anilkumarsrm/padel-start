`cachedMetadata.listItems` have a `task` field which is the single-character "status symbol".

- [ ] #task Todo
- [/] #task In Progress
- [x] #task Done ✅ 2024-05-26
- [-] #task Cancelled ❌ 2024-05-26
