<% tp.file.include("[[standard frontmatter]]") %>
# <% tp.file.title %>

<% tp.file.include("[[tags for related pages]]") %>
##
