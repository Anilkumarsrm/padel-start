# How the documentation is generated

We use [Obsidian Publish](https://obsidian.md/publish) for our documentation.
You can read more about it at the [Obsidian Help](https://help.obsidian.md/Obsidian+Publish/Introduction+to+Obsidian+Publish).

The `docs/` folder contains a properly configured Obsidian vault.

- To view and edit the Tasks help pages, **open `docs/` as a folder in Obsidian** on your machine.
