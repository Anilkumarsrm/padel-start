# Releasing the Tasks Plugin

- [[How do I make a release]]
